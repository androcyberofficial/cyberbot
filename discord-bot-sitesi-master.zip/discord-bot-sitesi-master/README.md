# discord-bot-sitesi

Noncentilyon için can sıkıntısından yaptığım öyle bir site 10 ya da 20 dkda falan yaptım kullanın :D

![Test Image 1](https://cdn.discordapp.com/attachments/712249377661648966/725719866103037952/unknown.png)
![Test Image 1](https://cdn.discordapp.com/attachments/712249377661648966/725720235273093120/unknown.png)

# Raksix tarafından yapılmıştır
